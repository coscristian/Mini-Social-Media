if(window.history.replaceState){
    // console.log("Probando");
    window.history.replaceState(null,null, window.location.href);

}